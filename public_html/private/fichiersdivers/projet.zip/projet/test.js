
/*
var jsonIssues = {};

$.ajax({
    url: "../MF_A-n4-Q2.out.json",
    async: false,
    dataType: 'json',
    success: function(value) {
        jsonIssues = value;
    }
});


var t = jsonIssues.d_1;

console.log(t);
*/
